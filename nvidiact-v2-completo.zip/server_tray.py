import requests
import subprocess
import threading
import time
import sys
import os
import json
import pystray
from PIL import Image, ImageDraw

# ─── CONFIGURAÇÃO ─────────────────────────────────────────────────────────────
API_URL = "https://nvidiact-api.onrender.com"
CONFIG_FILE = os.path.join(os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__), "config.json")

# ─── Chave do usuário ─────────────────────────────────────────────────────────
def load_key():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f).get("key", "")
        except:
            pass
    return ""

def save_key(key):
    with open(CONFIG_FILE, "w") as f:
        json.dump({"key": key}, f)

# ─── Caminho do EXE ───────────────────────────────────────────────────────────
def get_exe_path():
    base = os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__)
    return os.path.join(base, "KIPOCK FULL.exe")

# ─── Loop principal ───────────────────────────────────────────────────────────
running = True
user_key = ""
status_label = "Aguardando chave..."

def poll_loop():
    global status_label
    while running:
        if not user_key:
            time.sleep(2)
            continue
        try:
            resp = requests.post(
                f"{API_URL}/api/pc/register",
                json={"key": user_key},
                timeout=8
            )
            data = resp.json()
            if data.get("status") == "ok":
                status_label = "🟢 Conectado à API"
                command = data.get("command")
                if command == "ativar":
                    exe = get_exe_path()
                    if os.path.exists(exe):
                        subprocess.Popen([exe])
                        status_label = "✅ Programa ativado"
                    else:
                        status_label = "❌ EXE não encontrado"
                elif command == "desativar":
                    os.system('taskkill /f /im "KIPOCK FULL.exe" >nul 2>&1')
                    status_label = "⛔ Programa desativado"
            elif data.get("status") == "invalid":
                status_label = "❌ Chave inválida"
        except Exception as e:
            status_label = "⚠️ Sem conexão com API"
        time.sleep(3)

# ─── Ícone na bandeja ─────────────────────────────────────────────────────────
def create_icon_image():
    img = Image.new("RGB", (64, 64), color=(0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([8, 8, 56, 56], fill=(118, 185, 0))
    return img

def on_definir_chave(icon, item):
    import tkinter as tk
    from tkinter import simpledialog
    root = tk.Tk()
    root.withdraw()
    chave = simpledialog.askstring("NVIDIA CT", "Digite sua chave de acesso (XXXXXXX-XXXXXX):", parent=root)
    root.destroy()
    if chave:
        global user_key
        user_key = chave.strip().upper()
        save_key(user_key)

def on_status(icon, item):
    import tkinter as tk
    from tkinter import messagebox
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("NVIDIA CT Status", f"Chave: {user_key or 'Não definida'}\nStatus: {status_label}")
    root.destroy()

def on_sair(icon, item):
    global running
    running = False
    icon.stop()

def run_tray():
    menu = pystray.Menu(
        pystray.MenuItem("Definir Chave", on_definir_chave),
        pystray.MenuItem(lambda text: f"Status: {status_label}", on_status),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Sair", on_sair)
    )
    icon = pystray.Icon("NVIDIA CT", create_icon_image(), "NVIDIA CT", menu)
    icon.run()

# ─── Main ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    user_key = load_key()

    # Se não tem chave salva, pede na inicialização
    if not user_key:
        import tkinter as tk
        from tkinter import simpledialog
        root = tk.Tk()
        root.withdraw()
        chave = simpledialog.askstring("NVIDIA CT", "Digite sua chave de acesso (XXXXXXX-XXXXXX):")
        root.destroy()
        if chave:
            user_key = chave.strip().upper()
            save_key(user_key)

    # Inicia loop de polling em background
    t = threading.Thread(target=poll_loop, daemon=True)
    t.start()

    # Inicia bandeja do sistema
    run_tray()
