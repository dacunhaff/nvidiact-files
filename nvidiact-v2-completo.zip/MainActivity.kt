package com.remoteapp.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.remoteapp.R
import com.remoteapp.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val API_URL = "https://nvidiact-api.onrender.com/api/verify"
    private val KEY_REGEX = Regex("^[A-Z0-9]{7}-[A-Z0-9]{6}$")
    private var isFormatting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupKeyInput()

        binding.btnConfirm.setOnClickListener {
            validateKey(binding.etAccessKey.text.toString())
        }

        binding.etAccessKey.setOnEditorActionListener { _, _, _ ->
            validateKey(binding.etAccessKey.text.toString())
            true
        }
    }

    private fun setupKeyInput() {
        binding.etAccessKey.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isFormatting || s == null) return
                isFormatting = true
                var clean = s.toString().replace("-", "").uppercase().filter { it.isLetterOrDigit() }
                if (clean.length > 13) clean = clean.substring(0, 13)
                val formatted = if (clean.length > 7) "${clean.substring(0, 7)}-${clean.substring(7)}" else clean
                s.replace(0, s.length, formatted)
                isFormatting = false
            }
        })
    }

    private fun validateKey(key: String) {
        val upperKey = key.uppercase().trim()
        if (upperKey.isEmpty()) { showError("Digite a chave de acesso"); return }
        if (!KEY_REGEX.matches(upperKey)) {
            showError("Formato inválido — use: XXXXXXX-XXXXXX")
            shakeView(binding.cardKey); return
        }

        binding.btnConfirm.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            val status = checkLicense(upperKey)
            withContext(Dispatchers.Main) {
                binding.btnConfirm.isEnabled = true
                binding.progressBar.visibility = View.GONE
                when (status) {
                    "valid" -> {
                        // Passa a chave para o ModeMenuActivity
                        val intent = Intent(this@MainActivity, ModeMenuActivity::class.java)
                        intent.putExtra("key", upperKey)
                        startActivity(intent)
                        finish()
                    }
                    "blocked" -> { showError("Chave bloqueada. Contate o administrador."); shakeView(binding.cardKey) }
                    "invalid" -> { showError("Chave de acesso incorreta"); binding.etAccessKey.text?.clear(); shakeView(binding.cardKey) }
                    else -> { showError("Erro de conexão. Verifique sua internet."); shakeView(binding.cardKey) }
                }
            }
        }
    }

    private fun checkLicense(key: String): String {
        return try {
            val conn = URL(API_URL).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.outputStream.write("""{"key":"$key"}""".toByteArray())
            JSONObject(conn.inputStream.bufferedReader().readText()).getString("status")
        } catch (e: Exception) { "error" }
    }

    private fun showError(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun shakeView(view: View) {
        view.startAnimation(android.view.animation.AnimationUtils.loadAnimation(this, R.anim.shake))
    }
}
