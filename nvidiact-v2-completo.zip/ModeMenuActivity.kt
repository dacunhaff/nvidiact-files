package com.remoteapp.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.remoteapp.databinding.ActivityModeMenuBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ModeMenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityModeMenuBinding
    private val API_URL = "https://nvidiact-api.onrender.com"

    // Chave vinda da MainActivity via Intent
    private var userKey = ""

    private var statusJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityModeMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userKey = intent.getStringExtra("key") ?: ""

        binding.btnAtivar.setOnClickListener { sendCommand("ativar") }
        binding.btnDesativar.setOnClickListener { sendCommand("desativar") }

        // Atualiza status do PC a cada 4 segundos
        startStatusPolling()
    }

    override fun onDestroy() {
        super.onDestroy()
        statusJob?.cancel()
    }

    private fun startStatusPolling() {
        statusJob = CoroutineScope(Dispatchers.IO).launch {
            while (true) {
                val online = checkPcStatus()
                withContext(Dispatchers.Main) {
                    if (online) {
                        binding.tvStatus.text = "STATUS: ON"
                        binding.tvPrograma.text = "● Programa: ATIVO"
                    } else {
                        binding.tvStatus.text = "STATUS: OFF"
                        binding.tvPrograma.text = "○ Programa: INATIVO"
                    }
                }
                delay(4000)
            }
        }
    }

    private fun sendCommand(action: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = postJson("$API_URL/api/pc/command", """{"key":"$userKey","action":"$action"}""")
            withContext(Dispatchers.Main) {
                when (result) {
                    "ok" -> Toast.makeText(this@ModeMenuActivity, if (action == "ativar") "✅ Comando enviado!" else "⛔ Desativado!", Toast.LENGTH_SHORT).show()
                    "pc_offline" -> Toast.makeText(this@ModeMenuActivity, "PC offline. Abra o servidor no PC.", Toast.LENGTH_LONG).show()
                    else -> Toast.makeText(this@ModeMenuActivity, "Erro de conexão.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun checkPcStatus(): Boolean {
        return try {
            val resp = postJsonRaw("$API_URL/api/pc/status", """{"key":"$userKey"}""")
            JSONObject(resp).optBoolean("online", false)
        } catch (e: Exception) { false }
    }

    private fun postJson(url: String, body: String): String {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.outputStream.write(body.toByteArray())
            val resp = JSONObject(conn.inputStream.bufferedReader().readText())
            resp.optString("status", "error")
        } catch (e: Exception) { "error" }
    }

    private fun postJsonRaw(url: String, body: String): String {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.outputStream.write(body.toByteArray())
            conn.inputStream.bufferedReader().readText()
        } catch (e: Exception) { "{}" }
    }
}
