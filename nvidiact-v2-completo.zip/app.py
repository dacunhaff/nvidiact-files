from flask import Flask, request, jsonify, render_template_string
from datetime import datetime
import json, os

app = Flask(__name__)

LICENSES_FILE = "licenses.json"
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "DaCunhaX@2026")

# Estado dos PCs em memória: { "CHAVE": { "online": bool, "last_seen": str, "command": str|None } }
pc_states = {}

def load_licenses():
    if not os.path.exists(LICENSES_FILE):
        return {}
    with open(LICENSES_FILE, "r") as f:
        return json.load(f)

def save_licenses(data):
    with open(LICENSES_FILE, "w") as f:
        json.dump(data, f, indent=2)

def check_password(pwd):
    return pwd == ADMIN_PASSWORD

# ─── Verificar chave (app Android) ────────────────────────────────────────────
@app.route("/api/verify", methods=["POST"])
def verify():
    body = request.get_json(silent=True) or {}
    key = body.get("key", "").strip().upper()
    if not key:
        return jsonify({"status": "invalid"}), 400
    licenses = load_licenses()
    if key not in licenses:
        return jsonify({"status": "invalid"}), 200
    lic = licenses[key]
    if lic.get("active") is False:
        return jsonify({"status": "blocked"}), 200
    lic["last_seen"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    save_licenses(licenses)
    return jsonify({"status": "valid", "user": lic.get("user", "—")}), 200

# ─── PC: registrar presença e pegar comando ────────────────────────────────────
@app.route("/api/pc/register", methods=["POST"])
def pc_register():
    body = request.get_json(silent=True) or {}
    key = body.get("key", "").strip().upper()
    if not key:
        return jsonify({"status": "error", "msg": "key required"}), 400
    licenses = load_licenses()
    if key not in licenses or not licenses[key].get("active", True):
        return jsonify({"status": "invalid"}), 403
    if key not in pc_states:
        pc_states[key] = {"online": True, "last_seen": None, "command": None}
    pc_states[key]["online"] = True
    pc_states[key]["last_seen"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    command = pc_states[key].get("command")
    pc_states[key]["command"] = None
    return jsonify({"status": "ok", "command": command}), 200

# ─── App: enviar comando ao PC ─────────────────────────────────────────────────
@app.route("/api/pc/command", methods=["POST"])
def pc_command():
    body = request.get_json(silent=True) or {}
    key = body.get("key", "").strip().upper()
    action = body.get("action", "").strip()
    if not key or action not in ("ativar", "desativar"):
        return jsonify({"status": "error"}), 400
    licenses = load_licenses()
    if key not in licenses or not licenses[key].get("active", True):
        return jsonify({"status": "invalid"}), 403
    if key not in pc_states or not pc_states[key].get("online"):
        return jsonify({"status": "pc_offline"}), 200
    pc_states[key]["command"] = action
    return jsonify({"status": "ok"}), 200

# ─── App: verificar status do PC ──────────────────────────────────────────────
@app.route("/api/pc/status", methods=["POST"])
def pc_status():
    body = request.get_json(silent=True) or {}
    key = body.get("key", "").strip().upper()
    if not key:
        return jsonify({"online": False}), 200
    state = pc_states.get(key)
    if not state:
        return jsonify({"online": False}), 200
    last = state.get("last_seen")
    if last:
        diff = (datetime.utcnow() - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).total_seconds()
        if diff > 10:
            state["online"] = False
    return jsonify({"online": state.get("online", False)}), 200

# ─── Painel Admin ──────────────────────────────────────────────────────────────
PANEL_HTML = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NVIDIA CT — Painel de Licenças</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #0d0d0d; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; padding: 24px; }
  h1 { color: #76b900; font-size: 22px; margin-bottom: 20px; letter-spacing: 1px; }
  .badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; }
  .valid   { background: #1a3d1a; color: #5de85d; }
  .blocked { background: #3d1a1a; color: #e85d5d; }
  .online  { background: #1a3d1a; color: #5de85d; }
  .offline { background: #2a2a2a; color: #888; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #222; }
  th { color: #76b900; font-size: 13px; text-transform: uppercase; }
  tr:hover td { background: #1a1a1a; }
  .btn { padding: 6px 14px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: bold; }
  .btn-block  { background: #3d1a1a; color: #e85d5d; }
  .btn-active { background: #1a3d1a; color: #5de85d; }
  .btn-del    { background: #2a1a1a; color: #aaa; }
  form.add-form { display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; }
  form.add-form input { background: #1a1a1a; border: 1px solid #333; color: #eee; padding: 8px 12px; border-radius: 6px; font-size: 14px; }
  form.add-form input[name=key] { width: 180px; letter-spacing: 2px; text-transform: uppercase; }
  form.add-form input[name=user] { flex: 1; min-width: 140px; }
  form.add-form button { background: #76b900; color: #000; padding: 8px 18px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }
  .msg { margin-top: 12px; font-size: 13px; color: #76b900; }
  .login-box { max-width: 340px; margin: 80px auto; background: #1a1a1a; padding: 32px; border-radius: 12px; border: 1px solid #333; }
  .login-box h2 { color: #76b900; margin-bottom: 20px; }
  .login-box input { width: 100%; background: #111; border: 1px solid #333; color: #eee; padding: 10px 14px; border-radius: 6px; font-size: 15px; margin-bottom: 14px; }
  .login-box button { width: 100%; background: #76b900; color: #000; padding: 10px; border: none; border-radius: 6px; font-weight: bold; font-size: 15px; cursor: pointer; }
  .err { color: #e85d5d; font-size: 13px; margin-bottom: 10px; }
</style>
</head>
<body>
{% if not authed %}
<div class="login-box">
  <h2>🔐 NVIDIA CT</h2>
  {% if error %}<div class="err">{{ error }}</div>{% endif %}
  <form method="POST" action="/admin">
    <input type="password" name="password" placeholder="Senha do painel" autofocus>
    <button type="submit">Entrar</button>
  </form>
</div>
{% else %}
<h1>🟢 NVIDIA CT — Painel de Licenças</h1>
<form class="add-form" method="POST" action="/admin/add">
  <input type="hidden" name="password" value="{{ password }}">
  <input type="text" name="key" placeholder="XXXXXXX-XXXXXX" maxlength="14" required>
  <input type="text" name="user" placeholder="Nome do usuário" required>
  <button type="submit">+ Adicionar</button>
</form>
{% if msg %}<div class="msg">{{ msg }}</div>{% endif %}
<table>
  <tr>
    <th>Chave</th><th>Usuário</th><th>Status</th><th>PC</th><th>Último acesso</th><th>Ações</th>
  </tr>
  {% for key, lic in licenses.items() %}
  <tr>
    <td><code>{{ key }}</code></td>
    <td>{{ lic.get('user', '—') }}</td>
    <td>
      {% if lic.get('active', True) %}
        <span class="badge valid">ATIVA</span>
      {% else %}
        <span class="badge blocked">BLOQUEADA</span>
      {% endif %}
    </td>
    <td>
      {% if pc_states.get(key, {}).get('online') %}
        <span class="badge online">🟢 ONLINE</span>
      {% else %}
        <span class="badge offline">⚫ OFFLINE</span>
      {% endif %}
    </td>
    <td>{{ lic.get('last_seen', 'Nunca') }}</td>
    <td style="display:flex;gap:6px;flex-wrap:wrap">
      {% if lic.get('active', True) %}
        <form method="POST" action="/admin/toggle">
          <input type="hidden" name="password" value="{{ password }}">
          <input type="hidden" name="key" value="{{ key }}">
          <input type="hidden" name="action" value="block">
          <button class="btn btn-block" type="submit">Bloquear</button>
        </form>
      {% else %}
        <form method="POST" action="/admin/toggle">
          <input type="hidden" name="password" value="{{ password }}">
          <input type="hidden" name="key" value="{{ key }}">
          <input type="hidden" name="action" value="activate">
          <button class="btn btn-active" type="submit">Ativar</button>
        </form>
      {% endif %}
      <form method="POST" action="/admin/delete">
        <input type="hidden" name="password" value="{{ password }}">
        <input type="hidden" name="key" value="{{ key }}">
        <button class="btn btn-del" type="submit" onclick="return confirm('Remover esta chave?')">Remover</button>
      </form>
    </td>
  </tr>
  {% endfor %}
</table>
{% endif %}
</body>
</html>
"""

@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        pwd = request.form.get("password", "")
        if check_password(pwd):
            return render_template_string(PANEL_HTML, authed=True, licenses=load_licenses(), pc_states=pc_states, password=pwd, msg=None, error=None)
        return render_template_string(PANEL_HTML, authed=False, error="Senha incorreta", licenses={}, pc_states={}, password="", msg=None)
    return render_template_string(PANEL_HTML, authed=False, error=None, licenses={}, pc_states={}, password="", msg=None)

@app.route("/admin/add", methods=["POST"])
def admin_add():
    pwd = request.form.get("password", "")
    if not check_password(pwd):
        return render_template_string(PANEL_HTML, authed=False, error="Não autorizado", licenses={}, pc_states={}, password="", msg=None)
    key = request.form.get("key", "").strip().upper()
    user = request.form.get("user", "").strip()
    licenses = load_licenses()
    if key in licenses:
        msg = f"⚠️ Chave {key} já existe."
    else:
        licenses[key] = {"user": user, "active": True, "created": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), "last_seen": "Nunca"}
        save_licenses(licenses)
        msg = f"✅ Chave {key} adicionada para {user}."
    return render_template_string(PANEL_HTML, authed=True, licenses=licenses, pc_states=pc_states, password=pwd, msg=msg, error=None)

@app.route("/admin/toggle", methods=["POST"])
def admin_toggle():
    pwd = request.form.get("password", "")
    if not check_password(pwd):
        return render_template_string(PANEL_HTML, authed=False, error="Não autorizado", licenses={}, pc_states={}, password="", msg=None)
    key = request.form.get("key", "")
    action = request.form.get("action", "")
    licenses = load_licenses()
    if key in licenses:
        licenses[key]["active"] = (action == "activate")
        save_licenses(licenses)
    return render_template_string(PANEL_HTML, authed=True, licenses=licenses, pc_states=pc_states, password=pwd, msg=None, error=None)

@app.route("/admin/delete", methods=["POST"])
def admin_delete():
    pwd = request.form.get("password", "")
    if not check_password(pwd):
        return render_template_string(PANEL_HTML, authed=False, error="Não autorizado", licenses={}, pc_states={}, password="", msg=None)
    key = request.form.get("key", "")
    licenses = load_licenses()
    licenses.pop(key, None)
    pc_states.pop(key, None)
    save_licenses(licenses)
    return render_template_string(PANEL_HTML, authed=True, licenses=licenses, pc_states=pc_states, password=pwd, msg=f"🗑️ Chave {key} removida.", error=None)

@app.route("/")
def index():
    return jsonify({"service": "NVIDIA CT API v2", "status": "online"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
