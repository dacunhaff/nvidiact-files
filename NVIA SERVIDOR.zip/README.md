# 🟢 NVIDIA CT Server v2.0

Sistema de servidor para controle remoto do KIPOCK FULL via app Android.

---

## 📦 Como Compilar o .EXE

### Pré-requisitos:
- Python 3.8 ou superior instalado
- Windows 10/11

### Passos:

1. **Baixe os arquivos:**
   - `nvidia_server.py`
   - `build.bat`

2. **Execute o build:**
   - Dê duplo clique em `build.bat`
   - Aguarde a compilação (~2 minutos)

3. **Pronto!**
   - O arquivo estará em: `dist\NVIDIA_CT_Server.exe`
   - Tamanho aproximado: 15-20 MB

---

## 📤 Como Distribuir para Clientes

### Método 1 — Upload no GitHub (Recomendado)

1. Acesse: `github.com/dacunhaff/nvidiact-files`
2. Clique em **"Add file" → "Upload files"**
3. Arraste o `NVIDIA_CT_Server.exe`
4. Commit com mensagem: "Server v2.0"
5. Compartilhe o link de download:
   ```
   https://github.com/dacunhaff/nvidiact-files/raw/main/NVIDIA_CT_Server.exe
   ```

### Método 2 — Google Drive / Dropbox

1. Faça upload do `.exe` para nuvem
2. Gere link público
3. Compartilhe com clientes

---

## 👥 Instruções para o Cliente

### Instalação:

1. **Download:**
   - Baixe `NVIDIA_CT_Server.exe`
   - Salve em qualquer pasta (Ex: `C:\NVIDIA_CT\`)

2. **Primeira execução:**
   - Dê duplo clique no `.exe`
   - Digite sua chave de licença (formato: `XXXXXXX-XXXXXX`)
   - Clique OK

3. **Uso diário:**
   - O servidor inicia automaticamente na bandeja do sistema (ícone verde)
   - Deixe rodando enquanto usa o app Android

### Ícones de Status:

- 🟢 **Verde** = Conectado e funcionando
- 🟡 **Amarelo** = Aguardando conexão
- 🔴 **Vermelho** = Erro na chave ou conexão
- ⚫ **Cinza** = Desconectado

### Menu (clique direito no ícone):

- **Definir Chave** — Alterar chave de acesso
- **Status** — Ver informações da conexão
- **Forçar Ativar** — Ativar programa manualmente
- **Forçar Desativar** — Desativar programa manualmente
- **Ver Log** — Abrir arquivo de debug
- **Sair** — Fechar servidor

---

## 🔧 Solução de Problemas

### Cliente reclama que não conecta:

1. Verifique se a chave está correta no painel admin
2. Clique direito no ícone → **"Status"** para ver o erro
3. Clique direito → **"Ver Log"** e envie o arquivo para suporte

### Erro "Já está em execução":

- O servidor já está rodando na bandeja
- Procure o ícone verde perto do relógio
- Se não achar: abra o Gerenciador de Tarefas → Finalizar `NVIDIA_CT_Server.exe`

### Programa não ativa:

1. Verifique conexão com internet (precisa baixar o KIPOCK)
2. Desative antivírus temporariamente (pode bloquear o download)
3. Execute como Administrador (botão direito → "Executar como administrador")

---

## 📝 Logs e Debug

Os logs são salvos automaticamente em:
```
C:\caminho\onde\esta\o\exe\nvidia_server.log
```

Para enviar para suporte:
1. Clique direito no ícone → **"Ver Log"**
2. Copie o conteúdo do arquivo
3. Envie via WhatsApp/Email

---

## ✨ Melhorias da v2.0

✅ Não precisa instalar Python  
✅ Ícone dinâmico mostra status em tempo real  
✅ Notificações quando ativa/desativa  
✅ Sistema de log para debug  
✅ Previne múltiplas instâncias rodando  
✅ Menu mais intuitivo com ações manuais  
✅ Tratamento de erros melhorado  
✅ Primeira configuração guiada  

---

## 🔐 Segurança

- A chave fica salva em: `config.json` (mesmo diretório do .exe)
- Não expõe senhas ou dados sensíveis
- Conexão segura via HTTPS com a API
- Download verificado do GitHub oficial

---

## 📞 Suporte

- API: `https://nvidiact-api.onrender.com`
- Painel Admin: `https://nvidiact-api.onrender.com/admin`
- GitHub: `github.com/dacunhaff/nvidiact-files`
