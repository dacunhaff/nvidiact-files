@echo off
echo ========================================
echo  NVIDIA CT Server - Build Script
echo ========================================
echo.

REM Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado!
    echo Instale Python 3.8+ em python.org
    pause
    exit /b 1
)

echo [1/4] Instalando dependencias...
pip install pyinstaller pillow pystray requests

echo.
echo [2/4] Limpando builds anteriores...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist nvidia_server.spec del nvidia_server.spec

echo.
echo [3/4] Compilando para EXE...
pyinstaller --onefile --windowed --icon=NONE ^
    --name "NVIDIA_CT_Server" ^
    --add-data "config.json;." ^
    --hidden-import pystray._win32 ^
    --hidden-import PIL._tkinter_finder ^
    nvidia_server.py

echo.
echo [4/4] Finalizando...
if exist "dist\NVIDIA_CT_Server.exe" (
    echo.
    echo ========================================
    echo  BUILD CONCLUIDO COM SUCESSO!
    echo ========================================
    echo.
    echo Arquivo gerado: dist\NVIDIA_CT_Server.exe
    echo Tamanho: 
    dir "dist\NVIDIA_CT_Server.exe" | find "NVIDIA_CT_Server.exe"
    echo.
    echo Distribua este arquivo para os clientes!
    echo.
) else (
    echo.
    echo [ERRO] Build falhou!
    echo Verifique as mensagens de erro acima.
    echo.
)

pause
